Tic Tac Toe game with 3 levels of difficulty. At the 'difficult' level uses minimax algorithm, which makes it unbeatable. 
